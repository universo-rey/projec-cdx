# CODEX_EVOLUTIONARY_READBACK

**Gate:** `GATE_CODEX_USER_HOME_EVOLUTIONARY_AGENTIC_MACHINE_BLUEPRINT`  
**Estado:** `CODEX_LOCAL_EVOLUTIONARY_AGENTIC_MACHINE_BLUEPRINT_READY_NO_RUNTIME`  
**Modo:** blueprint read-only, sin runtime.

## 1. Dictamen breve

El adjunto cambia el diseño: `.codex` debe actuar como **cabina local evolutiva de coordinación**, no como simple carpeta de configuración ni como repo principal. La cabina procesa órdenes, genera evidencia, aprende de patrones, formula mejoras, prueba en sandbox documental y promueve capacidades solo bajo gate.

## 2. Estado actual de `.codex`

Estado inferido por adjuntos y conversación, no por inspección directa de la máquina.

- Existe `config.toml` según configuración pegada.
- Existe `AGENTS.md` funcional porque Codex resumió instrucciones activas.
- Codex CLI fue actualizado a `0.139.0` según salida compartida.
- Hay plugins y MCP `agent-skills` referenciados.
- No se inspeccionó físicamente `C:\Users\enzo1\.codex`.
- No se modificó `.codex`.
- No se creó estructura.
- No se activó runtime.
- No se tocaron tenants, conectores ni repos externos.

Ruta pendiente: el adjunto usa `C:\Users\enzo1.codex`, pero la ruta coherente es `C:\Users\enzo1\.codex`. Validar en próximo gate.

## 3. Máquina lineal, no lineal y evolutiva

- Lineal: pasos fijos.
- No lineal: ramifica y delega.
- Evolutiva: observa, aprende, repara, evalúa, promueve con gate y expande capacidades versionadas.

## 4. Planos operativos

1. Operación: órdenes, colas, task graphs, agentes, validación y readbacks.
2. Observación y memoria: patrones, fallos, decisiones saneadas y learning deltas.
3. Mejora y reparación iterativa: hipótesis, patch plan, fixture, eval y regression report.
4. Expansión gobernada: nuevas skills, agentes, perfiles, validadores, conectores declarados bloqueados, repos candidatos y versionado.

## 5. Ciclos evolutivos

A Orden a evidencia.  
B Evidencia a aprendizaje.  
C Aprendizaje a mejora.  
D Mejora a prueba.  
E Prueba a promoción.  
F Promoción a expansión.

## 6. Modelo de memoria

Guarda decisiones, patrones, fallos, criterios, rutas lógicas y evidencias saneadas. No guarda secretos, tokens, cookies, certificados privados, `.env`, dumps de conversación ni datos sensibles.

## 7. Modelo de mejora

```text
evidencia → patrón/fallo → hipótesis → patch mínimo → test → validación → decisión
```

## 8. Modelo de reparación iterativa

Cada repair loop registra review, hypothesis, patch_plan, test, validation, regression, decision, remaining_delta, next_iteration y stop_reason.

## 9. Modelo de evaluación

Se miden tasa de cierre, bloqueo, repetición, delta residual, errores, validadores faltantes, reintentos, escalamiento humano y mejoras promovidas/descartadas.

## 10. Modelo de expansión

Estados controlados:

```text
proposed → experiment → candidate → approved → applied → versioned
```

Sin `runtime_ready`, `production_ready` ni `connector_active` en este gate.

## 11. Política de promoción

Promoción solo con evidencia, test, regression report, rollback, gate explícito y decisión registrada.

## 12. Política de rollback

Cada promoción debe traer ROLLBACK_PLAN con qué revertir, cómo revertir, cómo verificar, qué evidencia conservar y qué versión queda vigente.

## 13. Matriz de agentes

Generada en `CODEX_AGENT_NETWORK_MATRIX.csv`.

## 14. Matriz de loops

Generada en `CODEX_EVOLUTION_LOOP_MATRIX.csv`.

## 15. Matriz de riesgos

Generada en `CODEX_RISK_MATRIX.csv`.

## 16. Archivos generados

- CODEX_EVOLUTIONARY_MACHINE_BLUEPRINT.md
- CODEX_EVOLUTION_LOOP_MATRIX.csv
- CODEX_AGENT_NETWORK_MATRIX.csv
- CODEX_MEMORY_MODEL.md
- CODEX_IMPROVEMENT_BACKLOG_SCHEMA.csv
- CODEX_REPAIR_LOOP_RECORD_SCHEMA.json
- CODEX_EXPANSION_GOVERNANCE.md
- CODEX_PROMOTION_POLICY.md
- CODEX_METRICS_AND_EVALS.md
- CODEX_EVOLUTIONARY_BOOTSTRAP_PLAN.md
- CODEX_EVOLUTIONARY_READBACK.md
- CODEX_RISK_MATRIX.csv
- CODEX_RESOURCE_REGISTRY_TEMPLATE.csv

## 17. Qué puede implementarse en el próximo gate

F1: crear estructura vacía bajo `.codex` con backup e inventario previo, sin runtime y sin conectores. También un validador documental para TOML duplicado, claves globales dentro de tabla, AGENTS.override activo, SKILL.md inválido y ruta ambigua.

## 18. Qué queda bloqueado

Modificar `.codex`, crear carpetas, tocar `.agents`, tocar CodexLocal, tocar repos externos, activar runtime, activar MCP nuevo, usar conectores, tocar tenants, usar Power Platform, hacer push, crear PR, autopromover mejoras y guardar secretos.

## 19. Próximo paso exacto

Ejecutar inventario read-only en PowerShell y pegar la salida:

```powershell
$CodexHome = "$env:USERPROFILE\.codex"
Write-Host "CODEX_HOME_TARGET=$CodexHome"
Test-Path $CodexHome
Get-ChildItem $CodexHome -Force | Select-Object Mode,LastWriteTime,Length,Name,FullName
```

## 20. Criterio de cierre

`CODEX_LOCAL_EVOLUTIONARY_AGENTIC_MACHINE_BLUEPRINT_READY_NO_RUNTIME`
