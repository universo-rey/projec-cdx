# CODEX_PROMOTION_POLICY

**Gate:** `GATE_CODEX_USER_HOME_EVOLUTIONARY_AGENTIC_MACHINE_BLUEPRINT`  
**Estado:** `CODEX_LOCAL_EVOLUTIONARY_AGENTIC_MACHINE_BLUEPRINT_READY_NO_RUNTIME`

## Objetivo

Definir cuándo una mejora puede pasar de propuesta a experimento, candidata, aprobada, aplicada, versionada o revertida.

## Estados

| Estado | Significado | Requisitos | Puede tocar producción |
|---|---|---|---:|
| propuesta | idea basada en evidencia | source_evidence + problema + beneficio esperado | No |
| experimento | cambio probado en sandbox/fixture | PATCH_PLAN + SYNTHETIC_EVAL_PLAN | No |
| candidata | experimento validado | REGRESSION_REPORT sin regresión crítica | No |
| aprobada | humano/gate acepta promoción | PROMOTION_DECISION + ROLLBACK_PLAN | No por defecto |
| aplicada | cambio implementado en superficie autorizada | evidencia + verificación | Solo con gate |
| versionada | release registrado | VERSIONING_PLAN + CHANGELOG | No aplica |
| revertida | cambio deshecho | ROLLBACK_REPORT | No aplica |

## Reglas de promoción

Una mejora solo puede promoverse si reduce delta residual, reduce riesgo, mejora claridad, aumenta trazabilidad, elimina repetición comprobada, agrega validador faltante, reduce intervención humana repetida o mejora rollback.

No se promueve porque “parece buena”.

## Gates mínimos

| Superficie | Gate |
|---|---|
| AGENTS.md | GATE_POLICY_DOC_CHANGE |
| config.toml | GATE_CONFIG_SAFE_PATCH |
| agents/*.config.toml | GATE_AGENT_CONFIG_CHANGE |
| skills | GATE_SKILL_EXPERIMENT |
| memory schema | GATE_MEMORY_MODEL_CHANGE |
| improvement loop | GATE_REPAIR_LOOP_CHANGE |
| expansion registry | GATE_EXPANSION_REGISTRY_CHANGE |
| MCP/runtime | GATE_RUNTIME_STUB |
| Codex Cloud | GATE_CLOUD_HANDOFF |
| tenant/M365/Intune/Power Platform | GATE_EXTERNAL_TENANT_ACTION |

## Evidencia requerida

Fuente del problema, decisión previa si existe, test o fixture, comparación antes/después, resultado de validación, regression report, rollback plan y readback final.

## Rollback

No se aprueba promoción sin rollback viable. Debe indicar qué archivo/recurso vuelve atrás, cómo verificar, qué evidencia conservar, qué memoria invalidar o marcar como revertida y qué versión queda vigente.

## Stop conditions

Bloquear promoción si no hay gate humano, evidencia, test o rollback; si hay secreto; si toca tenant o producción; si activa conector; si la memoria guarda datos sensibles; si el agente no tiene frontera; o si el registry copia recursos en vez de apuntarlos.
