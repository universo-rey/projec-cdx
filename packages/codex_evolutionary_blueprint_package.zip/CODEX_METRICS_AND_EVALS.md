# CODEX_METRICS_AND_EVALS

**Gate:** `GATE_CODEX_USER_HOME_EVOLUTIONARY_AGENTIC_MACHINE_BLUEPRINT`  
**Estado:** `CODEX_LOCAL_EVOLUTIONARY_AGENTIC_MACHINE_BLUEPRINT_READY_NO_RUNTIME`

## Objetivo

Medir si la cabina mejora con evidencia y sin aumentar riesgo.

## Métricas operativas

| Métrica | Definición | Fuente | Meta inicial |
|---|---|---|---|
| tasa_de_cierre | órdenes done / órdenes totales | FINAL_READBACK.md | subir |
| tasa_de_bloqueo | órdenes blocked / órdenes totales | FINAL_READBACK.md | bajar sin ocultar riesgo |
| tasa_de_review | órdenes review / órdenes totales | queues/review | controlada |
| tasa_de_escalamiento | órdenes escalated / órdenes totales | FINAL_READBACK.md | bajar con mejores agentes |
| tiempo_a_triage | inbox → triage | TRACE_INDEX.md | reducir |
| tiempo_a_readback | inbox → cierre | TRACE_INDEX.md | reducir |
| delta_residual | pendientes tras cierre | LEARNING_DELTA.md | reducir |
| tasa_de_repetición | patrones repetidos | PATTERN_REGISTRY.csv | reducir |
| validadores_faltantes | gaps de validación | GAP_BACKLOG.csv | reducir |
| mejoras_promovidas | promociones aprobadas / candidatas | PROMOTION_DECISION.md | subir con calidad |
| mejoras_descartadas | descartes / candidatas | PROMOTION_DECISION.md | saludable si evita riesgo |
| prompts_reintentados | tareas con reformulación | TRACE_INDEX.md | reducir |
| intervención_humana | tareas con input humano | EXECUTION_BOARD.md | reducir sin perder seguridad |

## Evals sintéticos

- TOML config validator fixture.
- SKILL.md frontmatter validator.
- Memory sanitizer fixture.
- Queue transition fixture.
- Task graph dependency fixture.
- Promotion gate fixture.
- Rollback completeness fixture.
- Codex Cloud handoff fixture.
- Tenant action blocker fixture.
- Power Platform no-write blocker fixture.

## Métricas de seguridad

| Métrica | Stop condition |
|---|---|
| secretos_detectados | detener memoria y promoción |
| conectores_activados_sin_gate | detener expansión |
| tenant_write_attempt | detener ejecución |
| git_remote_write_attempt | detener ejecución |
| agent_without_boundary | detener task graph |
| loop_without_stop_condition | detener blueprint |
| improvement_without_evidence | detener repair loop |

## Evaluación de mejora

Pasa si demuestra menos pasos manuales, menor ambigüedad, salida más estructurada, menor bloqueo injustificado, menor repetición, más trazabilidad, rollback más claro o riesgo igual/menor.

## Reporte mínimo

```text
EVAL_ID
input_fixture
expected_output
actual_output
pass_fail
delta_before
delta_after
risk_before
risk_after
regression_status
decision
```
