# CODEX_EVOLUTIONARY_MACHINE_BLUEPRINT

**Gate:** `GATE_CODEX_USER_HOME_EVOLUTIONARY_AGENTIC_MACHINE_BLUEPRINT`  
**Estado final:** `CODEX_LOCAL_EVOLUTIONARY_AGENTIC_MACHINE_BLUEPRINT_READY_NO_RUNTIME`  
**Modo:** blueprint read-only. No runtime. No modificación de `.codex`.

## Dictamen rector

`.codex` debe reconciliarse como **cabina local evolutiva de coordinación, aprendizaje operativo y expansión controlada de Codex Local**.

`.codex` no es repo principal, producto, canon institucional final, tenant, runtime productivo, depósito de secretos, backup de plataformas ni depósito principal de skills.

`.codex` sí debe contener o coordinar configuración de máquina, perfiles, agentes, políticas, colas, task graphs, templates, registries de punteros, memoria operativa liviana, ciclos de evaluación, propuestas de mejora, sandbox documental, readbacks y decisiones de promoción.

## Cambio frente al diseño anterior

Antes: `.codex` era casi solo configuración local.  
Ahora: `.codex` es una **cabina local**. Coordina, registra evidencia saneada, aprende y prepara expansión, pero no activa runtime productivo ni absorbe repos o plataformas.

Separación recomendada:

```text
C:\Users\enzo1\.codex          = cabina local de coordinación
C:\Users\enzo1\.agents\skills = skills personales reutilizables
CodexLocal\agentic-control-plane = repo versionado para desarrollar/runtime/skills fuente
Documents\GitHub\*              = repos de apps, plataformas, paquetes o automatizaciones
Codex Cloud                       = ejecución remota sobre repos/PRs/tests
Microsoft/GitHub/Power Platform   = plataformas externas administradas por punteros/APIs
```

## Ruta objetivo

El adjunto menciona `C:\Users\enzo1.codex`, pero por tus salidas previas y convención de Codex Home la ruta coherente es:

```text
C:\Users\enzo1\.codex
```

La ruta sin barra queda como **ambigua** y debe validarse en el próximo gate antes de crear nada.

## Por qué no es lineal

Una máquina lineal ejecuta pasos fijos. Una no lineal delega. Una evolutiva observa, aprende, prueba, valida y promueve bajo gate.

```text
orden
→ cola
→ arbitraje
→ grafo de tareas
→ agentes concurrentes
→ ejecución local permitida
→ validación interruptiva
→ evidencia
→ memoria operativa
→ detección de patrones
→ hipótesis de mejora
→ prueba controlada
→ evaluación
→ promoción gateada
→ nueva capacidad
→ nueva iteración
```

## Estructura objetivo, no crear todavía

```text
C:\Users\enzo1\.codex
├─ config.toml
├─ AGENTS.md
├─ agents
├─ profiles
├─ policies
├─ registries
├─ queues
│  ├─ inbox
│  ├─ triage
│  ├─ ready
│  ├─ active
│  ├─ waiting
│  ├─ blocked
│  ├─ review
│  ├─ done
│  └─ archive
├─ tasks
│  ├─ atomic
│  ├─ parallel
│  ├─ delegated
│  ├─ waiting
│  ├─ blocked
│  └─ completed
├─ memory
│  ├─ decisions
│  ├─ readbacks
│  ├─ patterns
│  ├─ failures
│  ├─ metrics
│  └─ learning_deltas
├─ improvement
│  ├─ hypotheses
│  ├─ experiments
│  ├─ repair_loops
│  ├─ evals
│  ├─ regression_reports
│  └─ promotion_candidates
├─ expansion
│  ├─ agent_factory
│  ├─ skill_gaps
│  ├─ profile_gaps
│  ├─ tool_gaps
│  ├─ repo_candidates
│  └─ versioning
├─ templates
├─ hooks
└─ runtime_state
```

## Plano 1 — Operación

Función: procesar órdenes reales de forma segura.

Componentes: queues, tasks, agents, profiles, policies, registries, validators, readbacks.

Agentes mínimos: order-intake, intent-classifier, risk-arbiter, context-router, authority-resolver, task-graph-builder, capability-selector, workspace-router, parallel-agent-dispatcher, dependency-checker, local-executor, validator, evidence-writer, closure-judge.

Salidas: `ORDER_PACKET.json`, `TASK_GRAPH.csv`, `EXECUTION_BOARD.md`, `VALIDATION_REPORT.md`, `FINAL_READBACK.md`.

## Plano 2 — Observación y memoria

Función: registrar lo ocurrido, medir calidad y detectar patrones.

Debe capturar órdenes repetidas, bloqueos, agentes que fallan, validadores faltantes, rutas ambiguas, skills ausentes, configs conflictivas, errores recurrentes, tareas que requieren humano, tiempos altos, prompts incompletos y decisiones repetidas.

Agentes mínimos: trace-collector, readback-miner, pattern-detector, failure-classifier, decision-memory-writer, gap-detector.

Salidas: `TRACE_INDEX.md`, `FAILURE_TAXONOMY.csv`, `PATTERN_REGISTRY.csv`, `DECISION_MEMORY.md`, `GAP_BACKLOG.csv`, `LEARNING_DELTA.md`.

## Plano 3 — Mejora y reparación iterativa

Función: convertir fallos y gaps en propuestas de mejora verificables y reversibles.

Ciclo: REVIEW → HYPOTHESIS → PATCH_PLAN → TEST → VALIDATE → DECIDE.

Agentes mínimos: improvement-hypothesis-builder, repair-loop-planner, fixture-builder, synthetic-eval-runner, validator-orchestrator, regression-checker, promotion-advisor.

Salidas: `IMPROVEMENT_HYPOTHESIS.md`, `REPAIR_LOOP_RECORD.json`, `SYNTHETIC_EVAL_PLAN.md`, `REGRESSION_REPORT.md`, `PROMOTION_DECISION.md`.

## Plano 4 — Expansión gobernada

Función: hacer crecer la máquina sin caos.

Expansiones posibles: nuevo agente, perfil, cola, validador, skill, recipe, template, registry, conector declarado bloqueado, repo candidato, automatización local, handoff a Codex Cloud, paquete para TCU.

Agentes mínimos: capability-expansion-planner, agent-factory-planner, skill-gap-proposer, registry-normalizer, promotion-gate-resolver, versioning-advisor, rollback-planner.

Salidas: `CAPABILITY_EXPANSION_MAP.csv`, `AGENT_FACTORY_BACKLOG.csv`, `SKILL_GAP_PROPOSALS.md`, `REGISTRY_CHANGE_PLAN.md`, `VERSIONING_PLAN.md`, `ROLLBACK_PLAN.md`.

## Modelo de colas

| Cola | Función | Estado permitido |
|---|---|---|
| inbox | recibir orden cruda | sin ejecución |
| triage | clasificar intención/riesgo | lectura |
| ready | tareas listas | delegables |
| active | ejecución controlada | solo permitido |
| waiting | espera humana/externa | no avanzar |
| blocked | stop condition | no ejecutar |
| review | validación humana/técnica | no promover |
| done | cierre validado | archivable |
| archive | histórico saneado | solo memoria |

## Modelo de madurez

| Nivel | Entrada | Salida | Evidencia | Stop condition | Próximo |
|---|---|---|---|---|---|
| L0 Inventario | config existente | inventario saneado | INVENTORY_READBACK.md | secreto detectado | L1 |
| L1 Procesamiento | colas definidas | readback | ORDER_PACKET + FINAL_READBACK | orden sin frontera | L2 |
| L2 Delegación | agentes declarados | task graph | TASK_GRAPH.csv | agente sin frontera | L3 |
| L3 Memoria | readbacks | patrones saneados | PATTERN_REGISTRY.csv | dato sensible | L4 |
| L4 Mejora | patrones | hipótesis | IMPROVEMENT_HYPOTHESIS.md | mejora sin evidencia | L5 |
| L5 Prueba | patch plan | eval | REGRESSION_REPORT.md | regresión crítica | L6 |
| L6 Promoción | eval aprobado | decisión | PROMOTION_DECISION.md | gate ausente | L7 |
| L7 Expansión | promoción | capacidad versionada | VERSIONING_PLAN.md | sin rollback | iteración |

## Frontera con GitHub y plataformas

Los repos son aplicaciones, runtimes, paquetes, automatizaciones o documentación versionada. `.codex` solo registra punteros y decisiones.  
GitHub, Microsoft 365, Intune, Power Platform, SharePoint, Teams, Slack y Codex Cloud son superficies externas. No se activan conectores ni se guardan secretos en este gate.

## Resultado

Este blueprint es implementable por fases, no toca producción, no habilita runtime, no activa conectores y exige promoción gateada.

`CODEX_LOCAL_EVOLUTIONARY_AGENTIC_MACHINE_BLUEPRINT_READY_NO_RUNTIME`
