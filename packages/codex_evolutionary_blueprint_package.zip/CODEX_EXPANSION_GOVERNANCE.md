# CODEX_EXPANSION_GOVERNANCE

**Gate:** `GATE_CODEX_USER_HOME_EVOLUTIONARY_AGENTIC_MACHINE_BLUEPRINT`  
**Estado:** `CODEX_LOCAL_EVOLUTIONARY_AGENTIC_MACHINE_BLUEPRINT_READY_NO_RUNTIME`

## Principio

La expansión se prepara, se prueba, se versiona y se promueve solo con gate. Ninguna capacidad se activa sola.

## Tipos de expansión

| Tipo | Descripción | Activación en este gate | Evidencia mínima | Gate |
|---|---|---:|---|---|
| Mejora interna | Ajuste de plantilla, policy, registry o validador | No | PATCH_PLAN + REGRESSION_REPORT | GATE_INTERNAL_IMPROVEMENT |
| Nueva skill | Skill nueva o experimental | No | SKILL_GAP_PROPOSAL + frontmatter válido + fixture | GATE_SKILL_EXPERIMENT |
| Nuevo agente | Agente declarativo con frontera | No | AGENT_FACTORY_BACKLOG + config propuesta | GATE_AGENT_FACTORY |
| Nuevo perfil | Perfil de modelo/rol/contexto | No | profile spec + risk review | GATE_PROFILE_CHANGE |
| Nuevo validador | Regla documental o estática | No | validator spec + fixture pass/fail | GATE_VALIDATOR_ADD |
| Nuevo conector | API/MCP/plugin externo | No | risk review + scopes + disabled default | GATE_CONNECTOR_DECLARE_ONLY |
| Nuevo repo | Repo candidato o paquete externo | No | repo candidate record + trust review | GATE_REPO_CANDIDATE |
| Nuevo runtime | MCP/Agents SDK/local executor | No | runtime stub + security model | GATE_RUNTIME_STUB |
| Nueva superficie externa | GitHub/M365/Intune/Power Platform/Slack/etc. | No | pointer-only registry + scope docs | GATE_EXTERNAL_SURFACE |

## Mejora interna vs expansión

- Mejora interna reduce delta dentro de una capacidad existente.
- Expansión agrega superficie, agente, skill, perfil, conector o runtime.

Toda expansión implica más riesgo que una mejora interna.

## Conectores declarados pero bloqueados

Un conector puede registrarse como puntero con nombre, plataforma, propósito, scopes previstos, ruta de documentación, estado `declared_blocked` y gate requerido. Nunca se guarda token o secreto.

## Nuevo repo candidato

Debe declarar nombre lógico, ubicación local esperada, remoto si existe, tipo, criticidad, si puede usar Codex Cloud, si contiene datos sensibles y gate de confianza.

## Estados prohibidos sin gate

```text
auto_enabled
production_ready
runtime_ready
connector_active
tenant_write_enabled
```

## Stop conditions

Detener expansión si no hay evidencia, no hay rollback, toca producción, activa conector, requiere secreto, abre permisos amplios, no define frontera, no define métricas o no puede revertirse.
