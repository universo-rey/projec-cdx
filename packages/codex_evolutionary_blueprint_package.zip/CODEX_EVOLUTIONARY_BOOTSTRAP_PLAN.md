# CODEX_EVOLUTIONARY_BOOTSTRAP_PLAN

**Gate:** `GATE_CODEX_USER_HOME_EVOLUTIONARY_AGENTIC_MACHINE_BLUEPRINT`  
**Estado:** `CODEX_LOCAL_EVOLUTIONARY_AGENTIC_MACHINE_BLUEPRINT_READY_NO_RUNTIME`

## F0 — Blueprint read-only

Objetivo: diseñar sin tocar `.codex`.

Entregables: blueprint, matrices, memory model, promotion policy, expansion governance, metrics/evals, bootstrap plan y readback.

Cierre: `CODEX_LOCAL_EVOLUTIONARY_AGENTIC_MACHINE_BLUEPRINT_READY_NO_RUNTIME`.

## F1 — Estructura vacía

Crear estructura objetivo en `.codex` solo después de gate.

No crear runtime. No activar conectores.

Evidencia: `TREE_BEFORE.md`, `TREE_AFTER.md`, `STRUCTURE_VALIDATION.md`.

## F2 — Colas y task schema

Crear schemas mínimos:

- `ORDER_PACKET.schema.json`
- `TASK_GRAPH.schema.csv`
- `EXECUTION_BOARD.template.md`
- `FINAL_READBACK.template.md`

Evidencia: `QUEUE_SCHEMA_VALIDATION.md`.

## F3 — Agentes y perfiles

Crear configs declarativas sin ejecución autónoma:

- `agents/*.config.toml`
- `profiles/*.toml`
- `policies/*.md`

Evidencia: `AGENT_BOUNDARY_REPORT.md`, `PROFILE_RISK_REPORT.md`.

## F4 — Memoria operativa saneada

Crear memoria mínima sin datos reales. Probar saneador con fixture sintético.

Evidencia: `MEMORY_SANITIZER_TEST.md`.

## F5 — Primer repair loop sintético

Usar un fixture documental, por ejemplo TOML duplicado.

Entregables: `IMPROVEMENT_HYPOTHESIS.md`, `PATCH_PLAN.md`, `SYNTHETIC_EVAL_PLAN.md`, `REPAIR_LOOP_RECORD.json`.

## F6 — Primer eval local

Ejecutar eval documental sin tocar config real.

Entregables: `EVAL_RESULT.md`, `REGRESSION_REPORT.md`.

## F7 — Promotion gate

Decidir si el validador/documento se promueve.

Entregables: `PROMOTION_DECISION.md`, `ROLLBACK_PLAN.md`, `NEXT_GATE.md`.

## F8 — Versionado en TCU o agentic-control-plane

Solo después de promoción: copiar a repo versionado, crear changelog, versionar artefactos, crear release local. No push sin gate.

## Stop conditions globales

Detener si aparece secreto, token, cookie, credencial, `.env`, certificado, clave privada, dato sensible, instrucción de activar conector, instrucción de tocar tenant, perfil con permisos excesivos, promoción automática, runtime activo o Git remote write.
