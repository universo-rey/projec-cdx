# CODEX_MEMORY_MODEL

**Gate:** `GATE_CODEX_USER_HOME_EVOLUTIONARY_AGENTIC_MACHINE_BLUEPRINT`  
**Estado:** `CODEX_LOCAL_EVOLUTIONARY_AGENTIC_MACHINE_BLUEPRINT_READY_NO_RUNTIME`

## Propósito

La memoria operativa de `.codex` sirve para aprender de decisiones, patrones, fallos y readbacks sin guardar secretos ni datos sensibles. No es base institucional completa ni backup de conversaciones.

## Qué se guarda

Permitido:

- decisiones operativas saneadas;
- criterios de ruteo;
- patrones repetidos;
- fallos clasificados;
- rutas lógicas;
- métricas agregadas;
- deltas de aprendizaje;
- próximos pasos;
- referencias a evidencia saneada;
- IDs internos no reversibles.

## Qué no se guarda

Prohibido:

- contraseñas, tokens, cookies, refresh tokens, client secrets;
- certificados privados, claves privadas SSH, `.env`;
- dumps de conversación;
- exports sensibles de tenants;
- archivos con datos personales;
- logs crudos con secretos;
- payloads API;
- cuerpos completos de skills/plugins/recipes si no corresponde.

## Saneamiento

1. Detectar patrones sensibles por nombre y contenido.
2. Redactar valores.
3. Mantener solo tipo de hallazgo y ubicación general.
4. Guardar referencia saneada.
5. Bloquear promoción si hay secreto no saneado.
6. En caso de duda, no guardar.

Formato:

```text
token: [REDACTED_TOKEN]
client_secret: [REDACTED_CLIENT_SECRET]
private_key: [REDACTED_PRIVATE_KEY]
```

## Uso para aprendizaje

La memoria alimenta `pattern-detector`, `failure-classifier`, `gap-detector`, `improvement-hypothesis-builder`, `repair-loop-planner` y `promotion-advisor`.

Un aprendizaje solo es válido con evidencia:

```text
learning_delta_id,evidence_ref,pattern_ref,proposed_action
LD-001,FINAL_READBACK-0001,PATTERN-002,Crear validador TOML de duplicados
```

## Versionado

Se versionan snapshots saneados:

```text
memory/decisions/DECISION_MEMORY.md
memory/patterns/PATTERN_REGISTRY.csv
memory/failures/FAILURE_TAXONOMY.csv
memory/learning_deltas/LEARNING_DELTA.md
```

Cada snapshot debe tener fecha, fuente y estado de saneamiento.

## Stop conditions

Detener escritura si aparece secreto, credencial, token, cookie, certificado privado, dato sensible, dump de conversación, evidencia sin sanear, contradicción de política o ruta productiva no autorizada.
