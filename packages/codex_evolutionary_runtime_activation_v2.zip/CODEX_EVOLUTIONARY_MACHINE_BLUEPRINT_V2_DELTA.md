# CODEX_EVOLUTIONARY_MACHINE_BLUEPRINT_V2_DELTA

## Dictamen corregido

El modelo correcto no es “.codex sin runtime” en sentido permanente.

El significado correcto de `CODEX_LOCAL_EVOLUTIONARY_AGENTIC_MACHINE_BLUEPRINT_READY_NO_RUNTIME` es:

- no se activa runtime durante el gate de blueprint;
- no se declara runtime listo;
- no se toca `.codex`;
- no se modifican conectores, tenants, repos ni servicios externos;
- pero el diseño sí debe prever que un agente especializado pueda activar runtime en un gate posterior.

## Corrección conceptual

La relación corregida es:

```text
Codex
  crea, sostiene, observa y coordina la cabina local

Agente activador de runtime
  decide si corresponde activar un runtime concreto,
  prepara el plan,
  verifica frontera,
  pide gate humano,
  activa solo si el gate está aprobado

Runtime
  ejecuta capacidades locales permitidas,
  siempre dentro de una frontera,
  siempre con trazabilidad,
  nunca como producción automática no gobernada
```

## Separación de responsabilidades

### Codex

Codex no debe ser tratado como runtime productivo. Codex:

- sostiene la sesión;
- lee instrucciones;
- coordina agentes;
- consulta skills;
- mantiene contexto operativo;
- usa configuración local;
- prepara planes;
- escribe evidencia;
- puede crear o preparar artefactos de runtime;
- no debe autopromover ni autoactivar capacidades críticas.

### Cabina `.codex`

`.codex` actúa como cabina local evolutiva. Puede contener o coordinar:

- configuración de máquina;
- perfiles;
- policies;
- agentes;
- colas;
- task graphs;
- registries de punteros;
- memoria saneada;
- readbacks;
- propuestas de mejora;
- decisiones de promoción;
- estado liviano de runtime;
- planos de activación;
- gates de runtime.

`.codex` no debe ser:

- repo principal;
- runtime productivo;
- depósito de secretos;
- backup de plataformas;
- depósito principal de skills;
- tenant;
- canon institucional final.

### Agente activador de runtime

Nuevo agente requerido:

```text
runtime-activation-controller
```

Propósito:

- recibir una intención de activar runtime;
- validar madurez mínima;
- resolver dependencia;
- comprobar seguridad;
- seleccionar runtime candidato;
- construir `RUNTIME_ACTIVATION_PLAN.md`;
- producir `RUNTIME_PRECHECK_REPORT.md`;
- pedir gate humano;
- activar solo si hay gate;
- generar evidencia posterior;
- registrar rollback.

Este agente no ejecuta por defecto. Es un agente con permiso potencial, pero bloqueado por gate.

## Nuevo ciclo evolutivo

### CICLO G — PROMOCIÓN A ACTIVACIÓN DE RUNTIME

Objetivo:

Convertir una capacidad promovida y versionada en runtime local activable.

Entrada:

- `PROMOTION_PACKAGE.md`
- `VERSIONING_PLAN.md`
- `RUNTIME_ACTIVATION_PLAN.md`
- `RUNTIME_PRECHECK_REPORT.md`

Procesador:

- `runtime-activation-controller`
- `risk-arbiter`
- `dependency-checker`
- `validator-orchestrator`
- `rollback-planner`

Salida:

- `RUNTIME_ACTIVATION_RECORD.json`
- `RUNTIME_HEALTHCHECK_REPORT.md`
- `RUNTIME_ROLLBACK_PLAN.md`
- `FINAL_RUNTIME_READBACK.md`

Criterio de éxito:

- runtime activado solo en frontera permitida;
- healthcheck correcto;
- evidencia generada;
- rollback documentado;
- gate humano registrado.

Stop conditions:

- secreto detectado;
- conector no aprobado;
- tenant involucrado sin autorización;
- dependencia faltante;
- perfil con permisos excesivos;
- ruta productiva no autorizada;
- healthcheck falla;
- rollback no existe;
- gate humano ausente.

## Frontera

La cabina puede sostener runtime local, pero la activación debe pasar por estados explícitos:

```text
declared
→ staged
→ prechecked
→ approved_for_activation
→ activated
→ healthchecked
→ monitored
→ suspended
→ retired
```

Ningún runtime pasa de `declared` a `activated` sin `approved_for_activation`.

## Estado actual corregido

El gate actual sigue siendo:

```text
CODEX_LOCAL_EVOLUTIONARY_AGENTIC_MACHINE_BLUEPRINT_READY_NO_RUNTIME
```

Pero el blueprint v2 reconoce explícitamente:

```text
RUNTIME_ACTIVATION_IS_AGENT_CONTROLLED_AND_GATE_REQUIRED
```

## Qué cambia respecto del blueprint anterior

Antes:

```text
Codex Cloud / local runtime quedaban como externos a la cabina.
```

Ahora:

```text
.codex es cabina de coordinación.
Codex sostiene la cabina.
Un agente especializado puede activar runtime en gate posterior.
El runtime activado queda bajo frontera, evidencia y rollback.
```

## Qué NO cambia

Siguen bloqueadas en este gate:

- modificaciones reales a `.codex`;
- creación de carpetas;
- activación de MCP;
- ejecución de conectores;
- ejecución de Microsoft 365, SharePoint, Power Platform, Slack, Azure u OpenAI API;
- declaración de runtime ready;
- declaración de production ready;
- autopromoción;
- guardado de secretos.

