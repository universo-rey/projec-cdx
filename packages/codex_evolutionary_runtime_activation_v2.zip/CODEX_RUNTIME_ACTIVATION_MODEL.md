# CODEX_RUNTIME_ACTIVATION_MODEL.md

## Modelo rector

El runtime no es activado por Codex de forma autónoma.

El runtime es activado por un agente especializado, bajo gate humano, usando a Codex como cabina de coordinación, observación, evidencia y sostén operativo.

## Entidades

### Codex

Rol: cabina/sustentador/orquestador.

Responsabilidades:

- mantener la sesión y el contexto;
- leer `AGENTS.md`, config, skills y registries;
- sostener colas, task graphs y readbacks;
- preparar planes y evidencia;
- invocar agentes o herramientas permitidas;
- no autopromover ni autoactivar runtime crítico.

### `.codex`

Rol: cabina local evolutiva.

Responsabilidades:

- almacenar configuración local;
- apuntar a perfiles;
- apuntar a registries;
- alojar colas livianas;
- alojar memoria saneada;
- alojar evidencia y readbacks;
- alojar estado liviano de runtime;
- registrar gates y decisiones.

### Runtime

Rol: plano de ejecución local controlado.

Puede ser:

- MCP server local;
- script runner PowerShell;
- runtime Agents SDK;
- worker local;
- validador local;
- evaluador sintético;
- orquestador de colas;
- adaptador a GitHub;
- adaptador a Codex Cloud;
- conector declarado pero bloqueado.

### Agente activador

Rol: autoridad operativa de activación.

Nombre:

```text
runtime-activation-controller
```

Responsabilidades:

- decidir si una capacidad ya está lista para staging;
- validar precondiciones;
- preparar activación;
- pedir gate;
- activar runtime solo si está aprobado;
- correr healthcheck;
- registrar evidencia;
- preparar rollback;
- suspender o revertir si falla.

## Estados de runtime

```text
referenced
  Existe una referencia documental o registry.

declared
  Está definido como capacidad candidata.

staged
  Tiene estructura y prerequisitos preparados en entorno no productivo.

prechecked
  Pasó validaciones previas.

approved_for_activation
  Gate humano aprobado.

activated
  Runtime encendido localmente en frontera permitida.

healthchecked
  Runtime respondió validaciones mínimas.

monitored
  Runtime activo y observado.

suspended
  Runtime pausado sin borrado.

retired
  Runtime retirado de forma documentada.
```

## Transiciones permitidas

| Desde | Hacia | Requisito |
|---|---|---|
| referenced | declared | Registry válido |
| declared | staged | Plan aprobado |
| staged | prechecked | Dependencias verificadas |
| prechecked | approved_for_activation | Gate humano |
| approved_for_activation | activated | Ejecución permitida |
| activated | healthchecked | Healthcheck correcto |
| healthchecked | monitored | Métricas mínimas |
| monitored | suspended | Gate o condición de parada |
| suspended | retired | Plan de retiro |

## Stop conditions

Detener activación si aparece:

- secreto;
- token;
- credencial;
- `.env`;
- certificado privado;
- ruta productiva no autorizada;
- falta de rollback;
- falta de evidencia;
- perfil con permisos excesivos;
- conector no aprobado;
- tenant involucrado sin autorización;
- scope demasiado amplio;
- runtime sin frontera;
- runtime sin healthcheck;
- runtime sin owner;
- runtime sin versión.

## Evidencias obligatorias

Antes de activar:

- `RUNTIME_ACTIVATION_PLAN.md`
- `RUNTIME_PRECHECK_REPORT.md`
- `RUNTIME_RISK_ASSESSMENT.md`
- `RUNTIME_ROLLBACK_PLAN.md`

Después de activar:

- `RUNTIME_ACTIVATION_RECORD.json`
- `RUNTIME_HEALTHCHECK_REPORT.md`
- `FINAL_RUNTIME_READBACK.md`

## Criterio de activación

Un runtime se puede activar solo si:

1. Tiene propósito claro.
2. Tiene frontera definida.
3. Tiene versión.
4. Tiene owner.
5. Tiene rollback.
6. Tiene healthcheck.
7. No requiere secretos expuestos.
8. No toca producción.
9. No activa conectores externos sin gate específico.
10. Tiene gate humano explícito.
